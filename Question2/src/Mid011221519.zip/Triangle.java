public class Triangle {
}
